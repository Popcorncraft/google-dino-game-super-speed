## t-rex-runner

the t-rex runner game extracted from chrome offline error page.
